import nextCoreWebVitals from 'eslint-config-next/core-web-vitals';
import nextTypescript from 'eslint-config-next/typescript';

const config = [
  { ignores: ['.next/**', 'next-env.d.ts', 'coverage/**'] },
  ...nextCoreWebVitals,
  ...nextTypescript,
  {
    rules: {
      'no-console': 'error',
    },
  },
];

export default config;
